package com.example.floatingnote;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 10, 14, 10);
        box.setBackgroundColor(Color.argb(235, 20, 28, 43));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView tag = new TextView(this);
        tag.setText("📌 یادداشت");
        tag.setTextColor(Color.WHITE);
        tag.setTypeface(null, Typeface.BOLD);
        tag.setTextSize(13);
        bar.addView(tag, new LinearLayout.LayoutParams(0, -2, 1));

        TextView close = new TextView(this);
        close.setText("  ✕  ");
        close.setTextColor(Color.WHITE);
        close.setTextSize(18);
        bar.addView(close);
        box.addView(bar);

        TextView content = new TextView(this);
        content.setText(getSharedPreferences("note", MODE_PRIVATE).getString("text", ""));
        content.setTextColor(Color.WHITE);
        content.setTextSize(16);
        content.setPadding(0, 8, 0, 2);
        content.setMaxWidth(290);
        box.addView(content);
        close.setOnClickListener(v -> stopSelf());

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 12;
        params.y = 80;

        final int[] start = new int[4];
        bar.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                start[0] = params.x; start[1] = params.y;
                start[2] = (int)e.getRawX(); start[3] = (int)e.getRawY();
                return true;
            } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = Math.max(0, start[0] - ((int)e.getRawX() - start[2]));
                params.y = Math.max(0, start[1] + ((int)e.getRawY() - start[3]));
                wm.updateViewLayout(panel, params);
                return true;
            }
            return false;
        });

        panel = box;
        try { wm.addView(panel, params); } catch (Exception ex) { stopSelf(); }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
