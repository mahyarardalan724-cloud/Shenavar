package com.example.floatingnote;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 501;
    private EditText note;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("note", MODE_PRIVATE);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setBackgroundColor(Color.rgb(17,24,39));

        TextView title = new TextView(this);
        title.setText("📌 یادداشت شناور");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.RIGHT);
        layout.addView(title);

        TextView help = new TextView(this);
        help.setText("متن را بنویس و «نمایش روی همه برنامه‌ها» را بزن. برای نمایش روی برنامه‌های دیگر، اجازه‌ی پنجره‌ی شناور لازم است.");
        help.setTextColor(Color.LTGRAY);
        help.setTextSize(15);
        help.setPadding(0, 16, 0, 18);
        layout.addView(help);

        note = new EditText(this);
        note.setTextColor(Color.WHITE);
        note.setHintTextColor(Color.GRAY);
        note.setHint("یادداشتت را اینجا بنویس...");
        note.setGravity(Gravity.TOP | Gravity.RIGHT);
        note.setMinLines(4);
        note.setText(prefs.getString("text", ""));
        layout.addView(note, new LinearLayout.LayoutParams(-1, 0, 1));

        Button show = new Button(this);
        show.setText("نمایش روی همه برنامه‌ها");
        layout.addView(show);
        show.setOnClickListener(v -> {
            prefs.edit().putString("text", note.getText().toString()).apply();
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, OVERLAY_REQUEST);
            } else {
                startOverlay();
            }
        });

        Button stop = new Button(this);
        stop.setText("قطع نمایش");
        layout.addView(stop);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        setContentView(layout);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (Settings.canDrawOverlays(this)) startOverlay();
            else Toast.makeText(this, "برای نمایش شناور باید اجازه را فعال کنی.", Toast.LENGTH_LONG).show();
        }
    }

    private void startOverlay() {
        prefs.edit().putString("text", note.getText().toString()).apply();
        Intent i = new Intent(this, OverlayService.class);
        startService(i);
        Toast.makeText(this, "یادداشت شناور فعال شد.", Toast.LENGTH_SHORT).show();
    }
}
